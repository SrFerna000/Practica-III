
package practica3;

import View.PanaderiaView;


public class Practica3 {


    public static void main(String[] args) {
        PanaderiaView view = new PanaderiaView();
        view.start();
       
    }
    
}
